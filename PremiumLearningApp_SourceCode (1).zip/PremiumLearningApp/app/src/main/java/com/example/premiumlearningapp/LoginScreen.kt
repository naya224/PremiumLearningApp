
package com.example.premiumlearningapp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.firestore.FirebaseFirestore

@Composable
fun LoginScreen(
    onLoginSuccess: () -> Unit
) {
    var name by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var password by remember { mutableStateOf("") }
    var isSignup by remember { mutableStateOf(false) }
    var errorMessage by remember { mutableStateOf("") }
    var isLoading by remember { mutableStateOf(false) }

    val purple = Color(0xFF6554C0)
    val auth = FirebaseAuth.getInstance()
    val firestore = FirebaseFirestore.getInstance()

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF6F5FA))
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.Center
    ) {

        Text(
            text = "Premium Learning",
            fontSize = 29.sp,
            fontWeight = FontWeight.Bold,
            color = purple
        )

        Spacer(modifier = Modifier.height(10.dp))

        Text(
            text = if (isSignup) "Create Your Account"
            else "Welcome Back!",
            fontSize = 21.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(25.dp))

        if (isSignup) {
            OutlinedTextField(
                value = name,
                onValueChange = { name = it },
                label = { Text("Full Name") },
                modifier = Modifier.fillMaxWidth(),
                singleLine = true
            )

            Spacer(modifier = Modifier.height(12.dp))
        }

        OutlinedTextField(
            value = email,
            onValueChange = { email = it },
            label = { Text("Email Address") },
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(12.dp))

        OutlinedTextField(
            value = password,
            onValueChange = { password = it },
            label = { Text("Password") },
            visualTransformation = PasswordVisualTransformation(),
            modifier = Modifier.fillMaxWidth(),
            singleLine = true
        )

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = {

                if (email.isBlank() || password.isBlank()) {
                    errorMessage = "Please enter email and password"

                } else if (!android.util.Patterns.EMAIL_ADDRESS
                        .matcher(email).matches()) {
                    errorMessage = "Please enter a valid email"

                } else if (password.length < 6) {
                    errorMessage = "Password must be at least 6 characters"

                } else if (isSignup && name.isBlank()) {
                    errorMessage = "Please enter your name"

                } else {

                    errorMessage = ""
                    isLoading = true

                    if (isSignup) {

                        // Firebase Signup
                        auth.createUserWithEmailAndPassword(
                            email.trim(),
                            password
                        ).addOnCompleteListener { task ->

                            if (task.isSuccessful) {

                                val userId = auth.currentUser?.uid

                                if (userId != null) {

                                    val userData = hashMapOf(
                                        "name" to name.trim(),
                                        "email" to email.trim()
                                    )

                                    firestore.collection("users")
                                        .document(userId)
                                        .set(userData)
                                        .addOnCompleteListener { saveTask ->

                                            isLoading = false

                                            if (saveTask.isSuccessful) {
                                                onLoginSuccess()
                                            } else {
                                                errorMessage =
                                                    "Account created, but profile could not be saved."
                                                onLoginSuccess()
                                            }
                                        }

                                } else {
                                    isLoading = false
                                    errorMessage = "User account not found"
                                }

                            } else {
                                isLoading = false
                                errorMessage =
                                    task.exception?.localizedMessage
                                        ?: "Signup failed"
                            }
                        }

                    } else {

                        // Firebase Login
                        auth.signInWithEmailAndPassword(
                            email.trim(),
                            password
                        ).addOnCompleteListener { task ->

                            isLoading = false

                            if (task.isSuccessful) {
                                onLoginSuccess()
                            } else {
                                errorMessage =
                                    task.exception?.localizedMessage
                                        ?: "Login failed"
                            }
                        }
                    }
                }
            },
            modifier = Modifier.fillMaxWidth(),
            enabled = !isLoading,
            colors = ButtonDefaults.buttonColors(
                containerColor = purple
            )
        ) {

            if (isLoading) {
                CircularProgressIndicator(
                    modifier = Modifier.size(22.dp),
                    color = Color.White,
                    strokeWidth = 2.dp
                )
            } else {
                Text(
                    text = if (isSignup) "Create Account" else "Login"
                )
            }
        }

        Spacer(modifier = Modifier.height(15.dp))

        TextButton(
            onClick = {
                isSignup = !isSignup
                errorMessage = ""
            },
            enabled = !isLoading
        ) {
            Text(
                text = if (isSignup)
                    "Already have an account? Login"
                else
                    "Don't have an account? Sign Up",
                color = purple
            )
        }

        if (errorMessage.isNotEmpty()) {
            Text(
                text = errorMessage,
                color = Color.Red,
                fontSize = 14.sp
            )
        }
    }
}

