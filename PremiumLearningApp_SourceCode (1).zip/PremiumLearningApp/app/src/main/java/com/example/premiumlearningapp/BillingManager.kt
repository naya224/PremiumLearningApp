
package com.example.premiumlearningapp

import android.app.Activity
import android.content.Context
import com.android.billingclient.api.*

class BillingManager(
    context: Context,
    private val onPurchaseResult: (String) -> Unit
) {

    private val purchasesUpdatedListener =
        PurchasesUpdatedListener { billingResult, purchases ->

            if (billingResult.responseCode ==
                BillingClient.BillingResponseCode.OK &&
                purchases != null
            ) {
                purchases.forEach { purchase ->
                    handlePurchase(purchase)
                }
            } else if (billingResult.responseCode ==
                BillingClient.BillingResponseCode.USER_CANCELED
            ) {
                onPurchaseResult("Purchase cancelled")
            } else {
                onPurchaseResult("Payment failed")
            }
        }

    private val billingClient = BillingClient.newBuilder(context)
        .setListener(purchasesUpdatedListener)
        .enablePendingPurchases(
            PendingPurchasesParams.newBuilder()
                .enableOneTimeProducts()
                .enablePrepaidPlans()
                .build()
        )
        .build()

    private var productDetailsList = listOf<ProductDetails>()

    fun startConnection() {
        billingClient.startConnection(
            object : BillingClientStateListener {

                override fun onBillingSetupFinished(
                    billingResult: BillingResult
                ) {
                    if (billingResult.responseCode ==
                        BillingClient.BillingResponseCode.OK
                    ) {
                        querySubscriptionProducts()
                    } else {
                        onPurchaseResult("Billing connection failed")
                    }
                }

                override fun onBillingServiceDisconnected() {
                    onPurchaseResult("Billing disconnected")
                }
            }
        )
    }

    private fun querySubscriptionProducts() {

        val products = listOf(
            QueryProductDetailsParams.Product.newBuilder()
                .setProductId("monthly_premium")
                .setProductType(BillingClient.ProductType.SUBS)
                .build(),

            QueryProductDetailsParams.Product.newBuilder()
                .setProductId("yearly_premium")
                .setProductType(BillingClient.ProductType.SUBS)
                .build()
        )

        val params = QueryProductDetailsParams.newBuilder()
            .setProductList(products)
            .build()

        billingClient.queryProductDetailsAsync(params) {
                result, queryResult ->

            if (result.responseCode ==
                BillingClient.BillingResponseCode.OK
            ) {
                productDetailsList = queryResult.productDetailsList
                onPurchaseResult("Products loaded successfully")
            } else {
                onPurchaseResult("Could not load products")
            }
        }
    }

    fun launchPurchase(activity: Activity, productId: String) {

        val product = productDetailsList.find {
            it.productId == productId
        }

        if (product == null) {
            onPurchaseResult("Product not found")
            return
        }

        val offerToken = product.subscriptionOfferDetails
            ?.firstOrNull()?.offerToken

        if (offerToken == null) {
            onPurchaseResult("Subscription offer unavailable")
            return
        }

        val productParams =
            BillingFlowParams.ProductDetailsParams.newBuilder()
                .setProductDetails(product)
                .setOfferToken(offerToken)
                .build()

        val billingParams = BillingFlowParams.newBuilder()
            .setProductDetailsParamsList(listOf(productParams))
            .build()

        billingClient.launchBillingFlow(activity, billingParams)
    }

    private fun handlePurchase(purchase: Purchase) {

        if (purchase.purchaseState ==
            Purchase.PurchaseState.PURCHASED
        ) {
            if (!purchase.isAcknowledged) {

                val params =
                    AcknowledgePurchaseParams.newBuilder()
                        .setPurchaseToken(purchase.purchaseToken)
                        .build()

                billingClient.acknowledgePurchase(params) { result ->
                    if (result.responseCode ==
                        BillingClient.BillingResponseCode.OK
                    ) {
                        onPurchaseResult("Purchase successful")
                    } else {
                        onPurchaseResult("Acknowledgement failed")
                    }
                }
            } else {
                onPurchaseResult("Purchase already acknowledged")
            }
        } else if (purchase.purchaseState ==
            Purchase.PurchaseState.PENDING
        ) {
            onPurchaseResult("Purchase is pending")
        }
    }

    fun restorePurchases() {

        val params = QueryPurchasesParams.newBuilder()
            .setProductType(BillingClient.ProductType.SUBS)
            .build()

        billingClient.queryPurchasesAsync(params) {
                result, purchases ->

            if (result.responseCode ==
                BillingClient.BillingResponseCode.OK
            ) {
                if (purchases.isEmpty()) {
                    onPurchaseResult("No active subscriptions")
                } else {
                    purchases.forEach { handlePurchase(it) }
                }
            }
        }
    }

    fun endConnection() {
        billingClient.endConnection()
    }
}
