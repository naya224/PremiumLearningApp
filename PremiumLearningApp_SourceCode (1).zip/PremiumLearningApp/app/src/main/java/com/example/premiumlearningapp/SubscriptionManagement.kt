
package com.example.premiumlearningapp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

@Composable
fun SubscriptionManagementScreen() {

    var currentPlan by remember {
        mutableStateOf("No Active Subscription")
    }

    var subscriptionStatus by remember {
        mutableStateOf("Inactive")
    }

    var showCancelDialog by remember {
        mutableStateOf(false)
    }

    val purple = Color(0xFF6554C0)

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF6F5FA))
            .padding(20.dp)
    ) {

        Text(
            text = "Manage Subscription",
            fontSize = 25.sp,
            fontWeight = FontWeight.Bold,
            color = purple
        )

        Spacer(modifier = Modifier.height(25.dp))

        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(
                containerColor = Color.White
            )
        ) {

            Column(
                modifier = Modifier.padding(20.dp)
            ) {

                Text(
                    text = "Current Plan",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(15.dp))

                Text(
                    text = currentPlan,
                    fontSize = 22.sp,
                    color = purple,
                    fontWeight = FontWeight.Bold
                )

                Spacer(modifier = Modifier.height(10.dp))

                Text("Status: $subscriptionStatus")

                Spacer(modifier = Modifier.height(10.dp))

                Text("Expiry Date: Available after purchase verification")

            }
        }

        Spacer(modifier = Modifier.height(25.dp))

        Text(
            text = "Subscription Options",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold
        )

        Spacer(modifier = Modifier.height(15.dp))

        Button(
            onClick = {
                currentPlan = "Monthly Premium"
                subscriptionStatus = "Demo Selection"
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = purple
            )
        ) {
            Text("Select Monthly Plan")
        }

        Spacer(modifier = Modifier.height(10.dp))

        Button(
            onClick = {
                currentPlan = "Yearly Premium"
                subscriptionStatus = "Demo Selection"
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(
                containerColor = purple
            )
        ) {
            Text("Select Yearly Plan")
        }

        Spacer(modifier = Modifier.height(20.dp))

        OutlinedButton(
            onClick = {
                showCancelDialog = true
            },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text(
                text = "Cancel Subscription",
                color = Color.Red
            )
        }

        Spacer(modifier = Modifier.height(15.dp))

        Text(
            text = "Note: Subscription changes and cancellation must be processed through Google Play.",
            color = Color.Gray,
            fontSize = 13.sp
        )
    }

    if (showCancelDialog) {

        AlertDialog(
            onDismissRequest = {
                showCancelDialog = false
            },
            title = {
                Text("Manage Cancellation")
            },
            text = {
                Text(
                    "To cancel an active subscription, open Google Play Store, go to Payments & subscriptions, then Subscriptions."
                )
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        showCancelDialog = false
                    }
                ) {
                    Text("OK")
                }
            }
        )
    }
}
