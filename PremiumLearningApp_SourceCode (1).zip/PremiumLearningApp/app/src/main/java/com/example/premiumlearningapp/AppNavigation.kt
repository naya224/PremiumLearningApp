
package com.example.premiumlearningapp

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import com.google.firebase.auth.FirebaseAuth

@Composable
fun AppNavigation() {

    var isLoggedIn by remember {
        mutableStateOf(FirebaseAuth.getInstance().currentUser != null)
    }

    var currentScreen by remember {
        mutableStateOf("home")
    }

    if (!isLoggedIn) {

        LoginScreen(
            onLoginSuccess = {
                isLoggedIn = true
                currentScreen = "home"
            }
        )

    } else {

        Column(
            modifier = Modifier.fillMaxSize()
        ) {

            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(8.dp),
                horizontalArrangement = Arrangement.SpaceEvenly
            ) {

                TextButton(
                    onClick = { currentScreen = "home" }
                ) {
                    Text("Home")
                }

                TextButton(
                    onClick = { currentScreen = "history" }
                ) {
                    Text("History")
                }

                TextButton(
                    onClick = { currentScreen = "subscription" }
                ) {
                    Text("Subscription")
                }

                TextButton(
                    onClick = {
                        FirebaseAuth.getInstance().signOut()
                        isLoggedIn = false
                    }
                ) {
                    Text("Logout")
                }
            }

            when (currentScreen) {

                "home" -> PremiumLearningApp()

                "history" -> PaymentHistoryScreen()

                "subscription" -> SubscriptionManagementScreen()
            }
        }
    }
}

