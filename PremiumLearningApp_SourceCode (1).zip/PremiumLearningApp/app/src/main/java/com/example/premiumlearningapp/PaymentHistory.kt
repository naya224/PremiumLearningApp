
package com.example.premiumlearningapp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp

data class PaymentRecord(
    val planName: String,
    val amount: String,
    val date: String,
    val transactionId: String,
    val status: String
)

@Composable
fun PaymentHistoryScreen() {

    val payments = remember {
        mutableStateListOf(
            PaymentRecord(
                planName = "Monthly Premium",
                amount = "$4.99",
                date = "Sample Date",
                transactionId = "DEMO-001",
                status = "Demo"
            ),
            PaymentRecord(
                planName = "Yearly Premium",
                amount = "$39.99",
                date = "Sample Date",
                transactionId = "DEMO-002",
                status = "Demo"
            )
        )
    }

    var selectedPayment by remember {
        mutableStateOf<PaymentRecord?>(null)
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF6F5FA))
            .padding(20.dp)
    ) {

        Text(
            text = "Payment History",
            fontSize = 26.sp,
            fontWeight = FontWeight.Bold,
            color = Color(0xFF6554C0)
        )

        Spacer(modifier = Modifier.height(8.dp))

        Text(
            text = "View your payment records and receipts",
            color = Color.Gray
        )

        Spacer(modifier = Modifier.height(20.dp))

        if (payments.isEmpty()) {

            Box(
                modifier = Modifier.fillMaxSize(),
                contentAlignment = Alignment.Center
            ) {
                Text("No payment records available")
            }

        } else {

            LazyColumn(
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {

                items(payments) { payment ->

                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(15.dp),
                        colors = CardDefaults.cardColors(
                            containerColor = Color.White
                        )
                    ) {

                        Column(
                            modifier = Modifier.padding(16.dp)
                        ) {

                            Text(
                                text = payment.planName,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            Text("Amount: ${payment.amount}")
                            Text("Date: ${payment.date}")
                            Text("Transaction ID: ${payment.transactionId}")

                            Text(
                                text = "Status: ${payment.status}",
                                color = Color(0xFF23834B),
                                fontWeight = FontWeight.Bold
                            )

                            Spacer(modifier = Modifier.height(10.dp))

                            Button(
                                onClick = {
                                    selectedPayment = payment
                                },
                                colors = ButtonDefaults.buttonColors(
                                    containerColor = Color(0xFF6554C0)
                                )
                            ) {
                                Text("View Receipt")
                            }
                        }
                    }
                }
            }
        }
    }

    selectedPayment?.let { payment ->

        AlertDialog(
            onDismissRequest = {
                selectedPayment = null
            },
            title = {
                Text("Payment Receipt")
            },
            text = {
                Column {
                    Text("Premium Learning App")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Plan: ${payment.planName}")
                    Text("Amount: ${payment.amount}")
                    Text("Date: ${payment.date}")
                    Text("Transaction ID: ${payment.transactionId}")
                    Text("Status: ${payment.status}")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Thank you for your purchase!")
                }
            },
            confirmButton = {
                TextButton(
                    onClick = {
                        selectedPayment = null
                    }
                ) {
                    Text("Close")
                }
            }
        )
    }
}
