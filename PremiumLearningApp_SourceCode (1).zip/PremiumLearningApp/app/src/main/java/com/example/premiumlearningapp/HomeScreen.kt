package com.example.premiumlearningapp

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.google.firebase.auth.FirebaseAuth

data class Course(
    val title: String,
    val description: String,
    val progress: Float,
    val lessonsCount: Int
)

@Composable
fun PremiumLearningApp() {
    val purple = Color(0xFF6554C0)
    val currentUser = FirebaseAuth.getInstance().currentUser
    val userName = currentUser?.displayName ?: currentUser?.email?.substringBefore("@") ?: "Learner"

    val courses = remember {
        listOf(
            Course("Jetpack Compose & Material 3", "Master modern Android UI development", 0.75f, 12),
            Course("Advanced Kotlin & Architecture", "Clean Architecture, Coroutines & Flow", 0.40f, 10),
            Course("Firebase & Cloud Backend", "Authentication, Firestore & Cloud Functions", 0.20f, 8),
            Course("Google Play Billing Library", "In-app purchases and subscriptions", 0.90f, 6)
        )
    }

    var selectedCourse by remember { mutableStateOf<Course?>(null) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFFF6F5FA))
            .padding(20.dp)
    ) {
        // Welcome Header
        Text(
            text = "Welcome back, $userName!",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = purple
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = "Continue your learning journey",
            color = Color.Gray,
            fontSize = 15.sp
        )

        Spacer(modifier = Modifier.height(20.dp))

        // Stats Card
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = purple)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = "Active Streak",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "🔥 5 Days",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
                Column(horizontalAlignment = Alignment.End) {
                    Text(
                        text = "Completed",
                        color = Color.White.copy(alpha = 0.8f),
                        fontSize = 14.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "14 Lessons",
                        color = Color.White,
                        fontSize = 22.sp,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Text(
            text = "Your Courses",
            fontSize = 20.sp,
            fontWeight = FontWeight.Bold,
            color = Color.Black
        )

        Spacer(modifier = Modifier.height(12.dp))

        LazyColumn(
            verticalArrangement = Arrangement.spacedBy(12.dp),
            modifier = Modifier.fillMaxSize()
        ) {
            items(courses) { course ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color.White),
                    onClick = { selectedCourse = course }
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = course.title,
                                fontSize = 18.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.Black
                            )
                            Text(
                                text = "${(course.progress * 100).toInt()}%",
                                fontSize = 14.sp,
                                fontWeight = FontWeight.Bold,
                                color = purple
                            )
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Text(
                            text = course.description,
                            fontSize = 14.sp,
                            color = Color.Gray
                        )

                        Spacer(modifier = Modifier.height(12.dp))

                        LinearProgressIndicator(
                            progress = { course.progress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp),
                            color = purple,
                            trackColor = purple.copy(alpha = 0.2f),
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Text(
                            text = "${course.lessonsCount} lessons total",
                            fontSize = 12.sp,
                            color = Color.DarkGray
                        )
                    }
                }
            }
        }
    }

    selectedCourse?.let { course ->
        AlertDialog(
            onDismissRequest = { selectedCourse = null },
            title = { Text(course.title) },
            text = {
                Column {
                    Text(course.description)
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Progress: ${(course.progress * 100).toInt()}%")
                    Text("Total Lessons: ${course.lessonsCount}")
                    Spacer(modifier = Modifier.height(10.dp))
                    Text("Ready to dive into the next lesson?")
                }
            },
            confirmButton = {
                Button(
                    onClick = { selectedCourse = null },
                    colors = ButtonDefaults.buttonColors(containerColor = purple)
                ) {
                    Text("Resume Learning")
                }
            },
            dismissButton = {
                TextButton(onClick = { selectedCourse = null }) {
                    Text("Close")
                }
            }
        )
    }
}
